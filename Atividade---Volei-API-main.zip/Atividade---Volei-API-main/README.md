# Atividade---Volei-API
Utilizar como exemplo o VolleyAPI-Imagem que está em anexo.  Conectar a api e mostrar a imagem que você escolher.  Implementar a api Tirar o print do processo Anexar em um documento no word e salvar em pdf  Salvar em tarefas o pdf e o link do seu projeto do GitHub se for fazer m dupla, cada um deverá anexar a atividade de forma individual.
